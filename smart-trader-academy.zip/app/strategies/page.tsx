export default function StrategiesPage() {
  return (
    <div>
      <h2 className="text-3xl font-semibold mb-4">Trading Strategies</h2>
      <p>Here you'll find playbooks for swing trading, scalping, and smart money setups.</p>
    </div>
  );
}
