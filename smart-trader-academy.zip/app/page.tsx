export default function HomePage() {
  return (
    <div className="text-center">
      <h2 className="text-4xl font-bold mb-4">Welcome to Smart Trader Academy</h2>
      <p className="text-lg mb-6">Master the art of trading using proven smart money strategies.</p>
      <a href="/learn" className="bg-blue-600 text-white px-6 py-3 rounded-lg shadow hover:bg-blue-700">Start Learning</a>
    </div>
  );
}
