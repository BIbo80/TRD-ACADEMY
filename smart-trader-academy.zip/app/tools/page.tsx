export default function ToolsPage() {
  return (
    <div>
      <h2 className="text-3xl font-semibold mb-4">Trading Tools</h2>
      <p>Access Pine Scripts, trading journals, and downloadable templates to support your journey.</p>
    </div>
  );
}
