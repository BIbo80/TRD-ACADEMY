export default function BlogPage() {
  return (
    <div>
      <h2 className="text-3xl font-semibold mb-4">Trading Blog</h2>
      <p>Latest articles, market analysis, and tips for traders.</p>
    </div>
  );
}
