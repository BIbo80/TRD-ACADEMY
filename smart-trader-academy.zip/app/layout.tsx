import './globals.css';
import { Inter } from 'next/font/google';
import Link from 'next/link';
import type { Metadata } from 'next';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'Smart Trader Academy',
  description: 'Learn how to trade like the pros with smart money concepts.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <header className="bg-gray-900 text-white p-4 shadow">
          <nav className="flex justify-between items-center max-w-6xl mx-auto">
            <h1 className="text-xl font-bold">Smart Trader Academy</h1>
            <ul className="flex space-x-4 text-sm">
              <li><Link href="/">Home</Link></li>
              <li><Link href="/learn">Learn</Link></li>
              <li><Link href="/strategies">Strategies</Link></li>
              <li><Link href="/tools">Tools</Link></li>
              <li><Link href="/blog">Blog</Link></li>
            </ul>
          </nav>
        </header>
        <main className="max-w-6xl mx-auto p-6">{children}</main>
        <footer className="bg-gray-100 text-center p-4 mt-12 text-sm">
          © 2025 Smart Trader Academy. All rights reserved.
        </footer>
      </body>
    </html>
  );
}
