export default function LearnPage() {
  return (
    <div>
      <h2 className="text-3xl font-semibold mb-4">Learn to Trade</h2>
      <ul className="list-disc list-inside">
        <li>Trading Basics</li>
        <li>Technical Analysis</li>
        <li>Smart Money Concepts</li>
        <li>Risk Management</li>
      </ul>
    </div>
  );
}
